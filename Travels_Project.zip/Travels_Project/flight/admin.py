from django.contrib import admin
from flight import models
from django.contrib import admin
from .models import fight_table

# Register your models here.
admin.site.register(fight_table)
# # admin.site.register(models.Airlines)
# admin.site.register(models.Airport)
# admin.site.register(models.Flights)
# admin.site.register(models.Reservation)